package r2;

public class Precedence {

	public static void main(String[] args) {
		double first, second, average;
		first = 422;
		second = 6753;
		average = (first + second)/2; //average = first + second / 2; is not the same//
		System.out.println("Average = "+ average);
	}

}
