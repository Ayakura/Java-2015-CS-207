package r2;

public class UnderstandDivision {

	public static void main(String[] args) {
		int number, lastDigit;
		number = 675;
		lastDigit = number%10;
		
		System.out.println("number/10 = " + number/10);  //int divided by 10//
		System.out.println(67%10);
		System.out.println("Last digit is " + lastDigit);
	}

}
